function hitungTotalSate() {
    const input = document.getElementById('qtyKambing')
    const qtyKambing = parseInt(document.getElementById('qtyKambing').value) || 0;
    

}